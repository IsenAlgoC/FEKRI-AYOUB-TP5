#include <stdio.h>
#include <stdlib.h>

#include "tab.h"

/*
* Une fonctin qui initialise le tableau
* avec gestion des erreurs: Tableau �gale � NULL et size < 0
*/
int initTab(int* tab, int size) {
	if (tab == NULL || size < 0) {
		return -1;
	}
	else {
		for (int i = 0; i < size; i++) {
			tab[i] = 0;
		}
		return size;
	}
}


/*
* Une fonction qui ajoute des �l�ments au tableau avec agrandissement si necessaire
*/
int* ajoutElementDansTableau(int* tab, int* size, int* nbElts, int element) {
	if (*size > *nbElts) {
		tab[*nbElts] = element;
		(*nbElts)++;
		return tab;
	}
	else {
		int* new_tab = realloc(tab, *size + TAILLEAJOUT);
		if (new_tab == NULL)
			return new_tab;
		tab = new_tab;
		tab[*nbElts] = element;
		(*nbElts)++;
		*size = *size + TAILLEAJOUT;
		return tab;
	}
}

TABLEAU newArray() {
	TABLEAU tab;
	//Si l'allocation �choue malloc renvoie NULL
	tab.elt = malloc(sizeof(int)*TAILLEINITIALE);
	tab.size = TAILLEINITIALE;
	tab.eltsCount = 0;
	return tab;
}

int incrementArraySize(TABLEAU* tab, int incrementValue) {
	tab->elt = realloc(tab->elt, tab->size + incrementValue);
	tab->size += incrementValue;
	if (tab->elt == NULL)
		return -1;
	else
		return tab->size + incrementValue;
}

int setElement(TABLEAU* tab, int pos, int element) {
	int error;
	if (pos > tab->size) {
		error=incrementArraySize(tab, pos + TAILLEAJOUT);
		if (error == -1) {
			return -1;
		}
		/*
		* Initialiser les cases entre la fin du tableau d'origine et le nouvel elt � 0
		*/
		for (int i = tab->eltsCount; i < pos; i++)
			tab->elt[i] = 0;
	}
	tab->elt[pos] = element;
	
}


int main() {
	/*
	* Tableau statique
	*/
	int myTab1[10];
	/*
	* Tableau dynamique
	*/
	int* myTab2 = malloc(sizeof(int)*TAB2SIZE);
	initTab(myTab1, 100);
	for (int i = 0; i < 20; i++) {
		myTab2[i] = i + 1;
		printf("myTab2[%d] = %d, ", i, myTab2[i]);
	}
	free(myTab2);
	return(EXIT_SUCCESS);
}