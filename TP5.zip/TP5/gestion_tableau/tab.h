#ifndef TAB_H
#define TAB_H

#define TAB2SIZE 100
#define TAILLEAJOUT 50
#define TAILLEINITIALE 100

typedef struct Tableau{
	int* elt; //le tableau d'entiers
	int size; //taille du tableau
	int eltsCount; //nbr d'elts dans le tableau 
}TABLEAU;

/*
* Allocation dynamique d'un nouveau tableau
*/
TABLEAU newArray();

/*
* modifier la taille d'un tableau
*/
int incrementArraySize(TABLEAU* tab, int incrementValue);

/*
* Ecrire un �l�ment � une position donn�e sans insertion 
*/
int setElement(TABLEAU* tab, int pos, int element);

#endif // !TAB_H
